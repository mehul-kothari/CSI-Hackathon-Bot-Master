from django.apps import AppConfig


class LuisConnectorConfig(AppConfig):
    name = 'luis_connector'
